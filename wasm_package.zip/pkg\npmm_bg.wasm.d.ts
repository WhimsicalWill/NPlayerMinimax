/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_gamecontroller_free(a: number): void;
export function create_game_controller(a: number): number;
export function gamecontroller_get_board(a: number): number;
export function gamecontroller_get_to_move(a: number): number;
export function gamecontroller_get_move_num(a: number): number;
export function gamecontroller_get_game_status(a: number): number;
export function gamecontroller_make_ai_move(a: number): void;
export function gamecontroller_make_human_move(a: number, b: number, c: number): void;
export function gamecontroller_get_valid_moves(a: number): number;
export function __wbindgen_exn_store(a: number): void;
