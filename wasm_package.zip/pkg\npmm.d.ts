/* tslint:disable */
/* eslint-disable */
/**
* @param {number} num_players
* @returns {GameController}
*/
export function create_game_controller(num_players: number): GameController;
/**
*/
export class GameController {
  free(): void;
/**
* @returns {Array<any>}
*/
  get_board(): Array<any>;
/**
* @returns {number}
*/
  get_to_move(): number;
/**
* @returns {number}
*/
  get_move_num(): number;
/**
* @returns {number}
*/
  get_game_status(): number;
/**
*/
  make_ai_move(): void;
/**
* @param {number} move_row
* @param {number} move_col
*/
  make_human_move(move_row: number, move_col: number): void;
/**
* @returns {Array<any>}
*/
  get_valid_moves(): Array<any>;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_gamecontroller_free: (a: number) => void;
  readonly create_game_controller: (a: number) => number;
  readonly gamecontroller_get_board: (a: number) => number;
  readonly gamecontroller_get_to_move: (a: number) => number;
  readonly gamecontroller_get_move_num: (a: number) => number;
  readonly gamecontroller_get_game_status: (a: number) => number;
  readonly gamecontroller_make_ai_move: (a: number) => void;
  readonly gamecontroller_make_human_move: (a: number, b: number, c: number) => void;
  readonly gamecontroller_get_valid_moves: (a: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {SyncInitInput} module
*
* @returns {InitOutput}
*/
export function initSync(module: SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
